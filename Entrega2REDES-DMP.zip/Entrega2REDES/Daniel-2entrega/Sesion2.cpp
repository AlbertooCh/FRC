//============================================================================
// ----------- PRACTICAS DE FUNDAMENTOS DE REDES DE COMUNICACIONES -----------
// ---------------------------- CURSO 2025/26 --------------------------------
// ----------------------------- SESION2.CPP ---------------------------------
//============================================================================

#include <stdio.h>
#include <iostream>
#include <stdio_ext.h>
#include "linkLayer.h"
#include "kbhit.h"

using namespace std;

void mostrarMAC(unsigned char *mac)
{
    for(int i = 0; i < 6; i++)
    {
        printf("%.2X", mac[i]);
        if(i < 5) printf(":");
    }
    printf("\n");
}

void EnviarCaracter(interface_t iface, char car,unsigned char *mac_src,unsigned char *mac_dst,unsigned char *type)
{
    unsigned char payload[1];
    payload[0] = (unsigned char)car;

    unsigned char *trama = BuildFrame(mac_src, mac_dst, type, payload);
    SendFrame(&iface, trama, 1);
}

char RecibirCaracter(interface_t iface)
{
    apacket_t trama = ReceiveFrame(&iface);

    if(trama.header.len <= 0 || trama.packet == NULL)
        return 0;

    if(trama.header.len < 15)
        return 0;

    return (char)trama.packet[14];
}

int main()
{
    interface_t iface;
    pcap_if_t *avail_ifaces = NULL;
    pcap_if_t *aux = NULL;
    char *vector[20];
    int i = 0;
    int seleccion;

    unsigned char mac_dst[6] = {0x46, 0x35, 0xC2, 0x20, 0x52, 0xE6};
    unsigned char type[2] = {0x30, 0x00};

    printf("\n");
    printf("----------------------------\n");
    printf("------ SESION 2 - FRC ------\n");
    printf("----------------------------\n");

    printf("Interfaces disponibles:\n");

    avail_ifaces = GetAvailAdapters();
    aux = avail_ifaces;

    while(aux != NULL && i < 20)
    {
        printf("[%d] %s\n", i, aux->name);
        vector[i] = aux->name;
        i++;
        aux = aux->next;
    }

    if(i == 0)
    {
        printf("No hay interfaces disponibles\n");
        return 1;
    }

    printf("Selecciona interfaz: ");
    cin >> seleccion;

    if(seleccion < 0 || seleccion >= i)
    {
        printf("Interfaz no valida\n");
        return 1;
    }

    setDeviceName(&iface, vector[seleccion]);
    GetMACAdapter(&iface);

    printf("Interfaz elegida: %s\n", vector[seleccion]);

    printf("La MAC origen es: ");
    mostrarMAC(iface.MACaddr);

    printf("La MAC destino es: ");
    mostrarMAC(mac_dst);

    int Puerto = OpenAdapter(&iface);

    if(Puerto != 0)
    {
        printf("Error al abrir el puerto\n");
        return 1;
    }

    printf("Puerto abierto correctamente\n");
    printf("Pulse los caracteres a enviar:\n");

    char c;
    int contador = 0;

    while(1)
    {
        // Enviar caracter si se pulsa tecla
        if(kbhit())
        {
            c = getch();

            if(c == 27)
                break;

            EnviarCaracter(iface, c, iface.MACaddr, mac_dst, type);
            printf("%c", c);
            fflush(stdout);
        }

        // Recibir caracter
        char recibido = RecibirCaracter(iface);

        if(recibido != 0)
        {
            printf("Recibido: %c\n", recibido);
            contador++;
            printf("Caracteres recibidos: %d\n", contador);
        }
    }

    CloseAdapter(&iface);

    printf("\nPuerto cerrado\n");

    return 0;
}